from django.apps import AppConfig


class HelperAppConfig(AppConfig):
    name = 'helper_app'
